import scrapy
import re
from os.path import basename
from scrapy_redis.spiders import  CrawlSpider
from urllib.parse import urljoin
class PornpicsspiderSpider(scrapy.Spider):
    name = "pornpicsspider"
    allowed_domains = ["pornpics.com"]
    start_urls = ["https://www.pornpics.com/japanese/"]

    def parse(self, response):
        personlist=response.xpath("//div[@id='main']/ul/li/a/@href").getall()
        for person in personlist:
            yield scrapy.Request(url=urljoin(response.url,person),callback=self.image_parse)



    def image_parse(self,response):

        dirname= response.xpath("//title/text()").get()
        image_url=response.xpath("//div[@id='main']/ul/li/a/@href").getall()
        for url in image_url:
            image_name=basename(url)
            yield {
                dirname:dirname,
                image_name:image_name,
                url:url
            }